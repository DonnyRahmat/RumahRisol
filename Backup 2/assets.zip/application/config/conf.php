<?php
  define("base", "http://localhost/RumahRisol/");

?>
